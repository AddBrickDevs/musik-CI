<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');  
/* 
| ------------------------------------------------------------------- 
| EMAIL CONFING 
| ------------------------------------------------------------------- 
| Configuration of outgoing mail server. 
| */   
/*
$config['protocol'] = "smtp";
$config['smtp_host'] = ""; // Example: ssl://smtp.gmail.com
$config['smtp_port'] = "465"; 
$config['smtp_timeout']	= '30';  
$config['smtp_user'] = "";  // Example: myEmail@gmail.com
$config['smtp_pass'] = ""; // Example: myPassword
$config['charset'] = "utf-8";
$config['mailtype'] = "html";
$config['newline'] = "\r\n";
*/
?>
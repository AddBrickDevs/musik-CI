<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_URI class */
require APPPATH."third_party/MX/URI.php";

class MY_URI extends MX_URI {}
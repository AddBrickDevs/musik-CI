<?php
class MY_User_agent extends CI_User_agent {

    public function __construct()
    {
        parent::__construct();
    }

    public function is_tablet()
    {
        //logic to check for tablet
    }
}
?>
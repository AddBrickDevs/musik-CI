 <div id="loginForm" >
  <h3 class="form-signin-heading"><?php echo ___("label_sing_in"); ?></h3>
  <input type="email" name="email" class="form-control" placeholder="<?php echo ___("label_email"); ?>" required autofocus>
  <input type="password" name="password1" class="form-control" placeholder="<?php echo ___("label_password"); ?>" required>            
  <button  onClick="login();" class="btn btn-primary" style="width:100%;margin-top:10px;margin-bottom:10px" type="button"><?php echo ___("label_login"); ?></button>                          
</div>